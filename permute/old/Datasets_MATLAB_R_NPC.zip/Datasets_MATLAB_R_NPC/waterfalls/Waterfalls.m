diary('loganalisiWATERFALLS.txt')

[data,code]=xlsimport('Waterfalls');
B=1000;
Y=data(:,3:end);
X=data(:,2);
panel=data(:,1);
options.labels.dims{2}=[data(3:end).name];
[P, T, options]= by_strata(panel,'NP_ReM',Y,X,'bal',B,-1,0); 

TT=zeros([B+1 5 15]);
for b=1:(B+1)
for j=1:5
for i=1:15
    TT(b,j,i)=sum(-T(b,i,j,:));
end
end
end

[PP]=t2p(TT);
PP(B+1,:,:)
size(PP)

P=reshape(PP,[B+1 5 3 5]);
options.Combdims=3; 
options.OUT=1;
P2=NPC(P,'F',options);
size(P2)
options.Combdims=2;
P3=NPC_FWE(P2,'F',options);

diary('OFF')
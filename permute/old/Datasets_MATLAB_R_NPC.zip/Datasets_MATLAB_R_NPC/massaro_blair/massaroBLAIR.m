diary('loganalisiMassaroBlair.txt')
%option 4 and 3
B=10000;
[D,data,code]=xlsimport('massaroBLAIR');
reminD(D)

stats={'t',':Y.^2'};
[P, T] = NP_2s_MA('Y','group',B,stats,'T',1,1);

pT=P(:,:,3);
pL=NPC(P(:,:,1:2),'L',1);
pF=NPC(P(:,:,1:2),'F',1);
pT=NPC(P(:,:,1:2),'T',1);
globalP=NPC([pT pL pF],'T',1);

diary('OFF')
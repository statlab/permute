diary('confocal.txt')

B=5000

[D,data,code]=xlsimport('confocal');
reminD(D)

T_NT=(v('T_NT')-1)*2-1;
FU_BA=(v('FU_BA')-1)*2-1;
Y=D(4:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Treated vs Untreated
%% Evaluating TREATMENT effect (separately for Baseline (t0) and 5 years FU (t1))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P_T_NT_byStrata=by_strata(FU_BA,'NP_ReM',Y,T_NT,'all',B,0,0);
options.labels.dims{2}=[Y.name];
options.labels.dimslabel{2}='response';
options.labels.dims{3}={'Baseline' 'FU'};
options.labels.dimslabel{3}='BASELINE vs FU';
pmat_show(P_T_NT_byStrata,.05,options);


options.Combdims=2;
P2_T_NT=NPC_FWE(P_T_NT_byStrata,'T',options);

options.Combdims=2;

options.OUT=0;
P_T_NT_dom(:,1,:)=NPC(P_T_NT_byStrata(:,1:3,:),'L',options);
P_T_NT_dom(:,2,:)=NPC(P_T_NT_byStrata(:,4:8,:),'L',options);
P_T_NT_dom(:,3,:)=P_T_NT_byStrata(:,9,:);
P_T_NT_dom(:,4,:)=NPC(P_T_NT_byStrata(:,10:14,:),'L',options);

options.OUT=1;
optdom=options;
optdom.labels.dims{2}={'domain 1' 'domain 2' 'domain 3' 'domain 4'}
P2_T_NT_dom=NPC_FWE(P_T_NT_dom,'T',optdom); 
pmat_show(P2_T_NT_dom,.05,optdom)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%evaluating differences T_1-T_0, separately for treated and untreated patients
%% Evaluating TIME effect
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_FU_BA_byStrata=by_strata(T_NT,'NP_ReM',Y,FU_BA,'all',B,0,0);
options.labels.dims{2}=[Y.name];
options.labels.dims{3}={'Untreated' 'Treated'}
options.labels.dimslabel{3}='Untreated vs Treated';
pmat_show(P_FU_BA_byStrata,.05,options)

P2_FU_BA=NPC_FWE(P_FU_BA_byStrata,'T',options);
pmat_show(P2_FU_BA,.05,options)

options.OUT=0;
options.Combdims=2;
P_FU_BA_dom(:,1,:)=NPC(P_FU_BA_byStrata(:,1:3,:),'L',options);
P_FU_BA_dom(:,2,:)=NPC(P_FU_BA_byStrata(:,4:8,:),'L',options);
P_FU_BA_dom(:,3,:)=P_FU_BA_byStrata(:,9,:);
P_FU_BA_dom(:,4,:)=NPC(P_FU_BA_byStrata(:,10:14,:),'L',options);

options.OUT=1;
optdom=options;
optdom.labels.dims{2}={'domain 1' 'domain 2' 'domain 3' 'domain 4'}
P2_FU_BA_dom=NPC_FWE(P_FU_BA_dom,'T',optdom); 
pmat_show(P_FU_BA_dom,.05,optdom)
pmat_show(P2_FU_BA_dom,.05,optdom)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Factorial design 22 for repeated measurements
%% Effects: Treated VS Untreated,  Baseline VS FU, interaction
DES=[ 1  1  1; 1 -1 -1; -1 1 -1;-1 -1 1]


levs= [FU_BA T_NT]*[1 2]';
options.labels.dims{3}={'FU_BA', 'T_NT', 'INTERACT'};
[P t options]=NP_ReM(Y,levs,DES,B,0,options);
options.labels.dimslabel{3}='Two-way MANOVA';
pmat_show(P,.05,options)

%combininig variables through factors
options.Combdims=3;
P_fact=NPC(P,'F',options);
%adjusting p-values
P2_fact=NPC_FWE(P,'T',options);
pmat_show(P2_fact,.05,options)

%combining variables within factors
options.Combdims=2;
P_var=NPC_FWE(P,'T',options);
pmat_show(P_var,.05,options)
Pdom(:,1,:)=NPC(P(:,1:3,:),'L',options);
Pdom(:,2,:)=NPC(P(:,4:8,:),'L',options);
Pdom(:,3,:)=P(:,9,:);
Pdom(:,4,:)=NPC(P(:,10:14,:),'L',options);

optdom=options;
optdom.labels.dims{2}={'domain 1' 'domain 2' 'domain 3' 'domain 4'}
P2dom=NPC_FWE(Pdom,'T',optdom); 
pmat_show(Pdom,.05,optdom)
pmat_show(P2dom,.05,optdom)

diary('OFF')
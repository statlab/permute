diary('loganalisiRATS.txt')
[D,data,code]=xlsimport('rats','Foglio1');

reminD(D)

[no Ts]=v(3:size(D,2));

[P,T] = NP_StOrd(Ts,'GROUP',1000,-1,'F',1);
pf=NPC(P,'F');
pfFWE=NPC_FWE(P,'T');

[P,T] = NP_StOrd(Ts,'GROUP',1000,-1,'L',1);
pl=NPC(P,'L');
plFWE=NPC_FWE(P,'T');

[P,T] = NP_StOrd(Ts,'GROUP',1000,-1,'T',1);
pt=NPC(P,'T');
ptFWE=NPC_FWE(P,'T');

diary('OFF')
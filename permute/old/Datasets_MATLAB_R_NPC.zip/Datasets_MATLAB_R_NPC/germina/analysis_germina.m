diary('germina.txt')
B=5000;
[D, germina]=xlsimport('germina');

[P T options]=np_2s(D(2:end),D(1),B,1);


% stesso risultato:
reminD(D)
[P T options]=np_2s({'Germinated','Weight','Surface','Surface2'},'Fertilizer',B,1);

% 
% stesso risultato:
% load NPCexample
% [P T]=np_2s(germina(:,2:end),germina(:,1),B,1);





% 
%  Testing equality in distribution for C independent samples 
%  for continuous (or dichotomous) variables (with or without missing values)
%  p-values: 
% 			 VARIABLES Y
%            		Y1        	Y2        	Y3        	Y4        
%            		0.080992   	0.09649    	0.026397   	0.036296   
% 


%combinazione di Tippett su tutte e 4 le variabili
NPC(P,'T',options);
% Non Parametric Combination procedure
%  VARIABLE	     Y1	     Y2	     Y3	     Y4
%  p-value		 0.0810	 0.0965	 0.0264	 0.0363
%  Comb Funct		 Tippett
%  p-GLOBAL		 0.0607


%combinazione di Fisher su tutte e 4 le variabili
NPC(P,'F',options);
% Non Parametric Combination procedure
%  VARIABLE	     Y1	     Y2	     Y3	     Y4
%  p-value		 0.0810	 0.0965	 0.0264	 0.0363
%  Comb Funct		 Fisher
%  p-GLOBAL		 0.0201


%combinazione di Fisher su lunghezza e lunghezza^2. Multiaspect. � un
%funzionale della superficie
options.labels.dims{2}={'Surface' 'Surface^2'};
options.labels.dims{3}=[D(1).name];

%io sostituirei la riga 51 con  la seguente
%options.labels.dims{3}=[D(1).name];



p_surf=NPC(P(:,[end-1:end]),'F',options);
% Non Parametric Combination procedure
%  VARIABLE	     Y1	     Y2
%  p-value		 0.0264	 0.0363
%  Comb Funct		 Fisher
%  p-GLOBAL		 0.0305


%combinazione di Fisher sui 3 aspetti
options.labels.dims{2}=[D(2:3).name]
options.labels.dims{2}{3}='Surface MA';
options.labels.dims{3}=[D(1).name];
NPC_FWE([P(:,[1 2]) p_surf],'F',options);
% Closed Testing procedure
%  VARIABLE	     Y1	     Y2	     Y3
%  p-value		 0.0810	 0.0965	 0.0305
%  p-FWE  		 0.0810	 0.0965	 0.0444
%  Comb Funct		 Fisher
%  p-GLOBAL		 0.0205


%combinazione di Tippett sui 3 aspetti
NPC_FWE([P(:,[1 2]) p_surf],'T',options);

% Closed Testing procedure
%  VARIABLE	     Y1	     Y2	     Y3
%  p-value		 0.0810	 0.0965	 0.0305
%  p-FWE  		 0.1560	 0.1560	 0.0644
%  Comb Funct		 Tippett
%  p-GLOBAL		 0.0644
 diary('OFF')
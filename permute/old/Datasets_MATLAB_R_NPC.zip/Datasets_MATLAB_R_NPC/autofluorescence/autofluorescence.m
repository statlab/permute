diary('autofluorescence.txt')
B=1000;


[Ddemo]=xlsimport('Autofluor.xls','demo');
[Doct]=xlsimport('Autofluor.xls','OCT');
Doct(67+(1:4))=Ddemo(1:4);
Doct=Doct([end-(3:-1:0) 1:(end-4)]);
[lDoct]=w2lD(Doct, 6,66);


[Dmicro]=xlsimport('Autofluor.xls','MICRO');
[lDmicro]=w2lD(Dmicro, 2,66);
[Dautofl]=xlsimport('Autofluor.xls','AUTOFL');
[lDautofl]=w2lD(Dautofl, 2,66);
[Dpigmento]=xlsimport('Autofluor.xls','PIGMENTO');
[lDpigmento]=w2lD(Dpigmento, 2,66);
[Ddrusen]=xlsimport('Autofluor.xls','DRUSEN');
[lDdrusen]=w2lD(Ddrusen, 2,66);

lD=lDoct;
lD(end+1)=lDmicro(end);
lD(end+1)=lDautofl(end);
lD(end+1)=lDpigmento(end);
lD(end+1)=lDdrusen(end);

reminD(lD)
%             csvexport('autofl2.csv',lD)

B=1000%space_perm(13,1000);
[P, T, options] = NP_rho({'OCT' 'MICRO'} ,{'AF' 'PIG' 'DRU'},'Time',B,-1,'Pearson',1);
options.Combdims=4;
P2=NPC(P,'F',options);
options.Combdims=2;
P3fwe=NPC_FWE(P2,'T',options);


B=Space_Perm(13,1000);
[P, T] = by_strata(lD(1),'NP_StOrd',lD(7:8) ,lD(9:11),B,-1);

options.Combdims=4;
P2_F=NPC(P,'F',options);
P2_D=NPC(T,'D',options);

options.Combdims=2;
P3fweF=NPC_FWE(P2_F,'T',options);
P3fweD=NPC_FWE(P2_D,'T',options);

diary('OFF')


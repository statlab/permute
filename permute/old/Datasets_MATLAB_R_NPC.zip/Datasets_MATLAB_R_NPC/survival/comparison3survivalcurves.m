diary('3groups.txt')

[D,data,code]=xlsimport('3groups');
reminD(D)

G=data(:,1);
Z=data(:,2:end);
B=1000;

[PP,TT]=NP_Cs(Z,G,B,1);

diary('OFF')
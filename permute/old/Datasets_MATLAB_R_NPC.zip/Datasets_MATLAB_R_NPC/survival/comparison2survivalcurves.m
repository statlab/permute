diary('2groups.txt')

[D,data,code]=xlsimport('2groups');
reminD(D)
G=data(:,1);
Z=data(:,2:end);
B=1000;

[PP,TT]=NP_2s(Z,G,B,0);

diary('OFF')
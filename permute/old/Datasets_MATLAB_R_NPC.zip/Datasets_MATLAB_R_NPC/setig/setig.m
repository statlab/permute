diary('setig.txt')

[Daties]=xlsread('setig');

X=Daties(:,2);
Y=Daties(:,3:6);
strata=Daties(:,1);

[P, T] = by_strata(strata,'NP_2s',Y ,X,10000);

P2_F=NPC(P,'F',1);
P2a_F=NPC_FWE(P,'F',1);

P3_F=NPC(P2_F,'F',1);

diary('OFF')


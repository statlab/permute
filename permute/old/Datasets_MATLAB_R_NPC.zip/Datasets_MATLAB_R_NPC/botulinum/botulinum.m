diary('botulinum.txt')

B=1000;
[code,data]=xlsimport('botulinum');

options.labels.dims{2}=[code(5:end).name code(5:end).name code(5:end).name];
Y=data(:,5:end);
baseline=Y(1:20,:);
FU1=Y(21:40,:);
FU2=Y(41:60,:);
FU3=Y(61:80,:);

Y2=zeros(20, 24*3);
 
Y2(:,1:24)=FU1-baseline;
Y2(:,25:48)=FU2-baseline;
Y2(:,49:72)=FU3-baseline;

group=data(1:20,4);
alt=[1*ones(1,19) -1*ones(1,5) 1*ones(1,19) -1*ones(1,5) 1*ones(1,19) -1*ones(1,5)];
[P, T, options] = NP_2s(Y2,group,B,alt,options);


P=reshape(P,B+1,24,3);

for i=1:24
    options.labels.dims{2}{i}=options.labels.dims{2}{i}(find((options.labels.dims{2}{i}==options.labels.dims{2}{24+i}).*(options.labels.dims{2}{i}==options.labels.dims{2}{48+i})));
end
options.labels.dims{2}=options.labels.dims{2}(1:24);

options.labels.dims{3}={'baseline-1week','baseline-1month','baseline-6months'};

%pMat_Show(P,.05,options.labels,1);

%combining times
options.Combdims=3;
P2=NPC(P,'F',options);


%multiplicity control over variables 
options.Combdims=2;
p2_FWE=NPC_FWE(P2,'T',options);

diary('OFF')
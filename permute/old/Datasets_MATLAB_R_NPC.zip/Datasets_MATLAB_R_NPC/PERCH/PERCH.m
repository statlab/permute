diary('loganalisiPERCH.txt')

[D]=xlsimport('perch');
reminD(D)

varYordinal=[5:22, 24:26, 30]
varYquant=[23, 27:29, 31:32]

B=1000

D_=D;
for i=1:length(D)
    D(i).vals=D(i).vals(D_(4).vals==4);
end
reminD(D)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B=Space_perm(length(v('dose')),B);

[Pquant, T,  options_q,p_sub, T_sub] = NP_StOrd(D(varYquant),'dose',B,-1,'F');

[doseDUMMY, orig,w,labelsDUMMY] = expand_categ('dose',2);

options_o.labels.dims{3}=labelsDUMMY;
options_o.tail=-1;
[Pc, Tc, options_o, P_sub, T_sub] = NP_Cs_Categ(D(varYordinal),doseDUMMY,B,2,'F',options_o);

Pordinal=NPC(Pc,'F',options_o);

options=options_o;
options.Combdims=2;

options.labels.dims{2}=[D([varYordinal(:,1:18) varYquant(:,1) varYordinal(:,19:21) varYquant(:,2:4) varYordinal(:,22) varYquant(:,5:6)]).name];
P=[Pordinal(:,1:18) Pquant(:,1) Pordinal(:,19:21) Pquant(:,2:4) Pordinal(:,22) Pquant(:,5:6)];

fprintf('\n*************Results: time 4\n')
P2=NPC_FWE(P,'T',options);

domains=[1 1 1 1 1 1 2 2 2 2 3 3 3 3 3 3 4 4 4 5 5 5 5 5 5 6 6 6];
 


%Domains
     
for i=1:6 %i domini
    optionsD.labels.dims{2}=options.labels.dims{2}(domains==i)
    PD(:,i)=NPC(P(:,domains==i),'F',optionsD);
end
  
NPC_fwe(PD,'T');
P_4=P; %storing results for time=4 
PD_4=PD;

%analyzing time=0

[D]=xlsimport('perch');

D_=D;
for i=1:length(D)
    D(i).vals=D(i).vals(D_(4).vals==0);
end
reminD(D)

[Pquant, T,  options_q,p_sub, T_sub] = NP_StOrd(D(varYquant),'dose',B,-1,'F');

[doseDUMMY, orig,w,labelsDUMMY] = expand_categ('dose',2);
options_o.labels.dims{3}=labelsDUMMY;
options_o.tail=-1;
[Pc, Tc,options_o P_sub, T_sub, ] = NP_Cs_Categ(D(varYordinal),doseDUMMY,B,2,'F',options_o);
Pordinal=NPC(Pc,'F',options_o);

options=options_o;
options.Combdims=2;

options.labels.dims{2}=[D([varYordinal(:,1:18) varYquant(:,1) varYordinal(:,19:21) varYquant(:,2:4) varYordinal(:,22) varYquant(:,5:6)]).name];
P_0=[Pordinal(:,1:18) Pquant(:,1) Pordinal(:,19:21) Pquant(:,2:4) Pordinal(:,22) Pquant(:,5:6)];

fprintf('\n*************Results: time 0\n')
P2=NPC_fwe(P_0,'T',options);

%Domains: t0.
     
for i=1:6 %i domini
    optionsD.labels.dims{2}=options.labels.dims{2}(domains==i)
    PD_0(:,i)=NPC(P_0(:,domains==i),'F',optionsD);
end


NPC_fwe(PD_0,'T');

%analyzing time=24

[D]=xlsimport('perch');
D_=D;
for i=1:length(D)
    D(i).vals=D(i).vals(D_(4).vals==24);
end
reminD(D)

[Pquant, T,  options_q,p_sub, T_sub] = NP_StOrd(D(varYquant),'dose',B,-1,'F');
[doseDUMMY, orig,w,labelsDUMMY] = expand_categ('dose',2);
options_o.labels.dims{3}=labelsDUMMY;
options_o.tail=-1;
[Pc, Tc,options_o P_sub, T_sub, ] = NP_Cs_Categ(D(varYordinal),doseDUMMY,B,2,'F',options_o);
Pordinal=NPC(Pc,'F',options_o);
options=options_o;

options.labels.dims{2}=[D([varYordinal(:,1:18) varYquant(:,1) varYordinal(:,19:21) varYquant(:,2:4) varYordinal(:,22) varYquant(:,5:6)]).name];
P_24=[Pordinal(:,1:18) Pquant(:,1) Pordinal(:,19:21) Pquant(:,2:4) Pordinal(:,22) Pquant(:,5:6)];

fprintf('\n*************Results: time 24\n')
options.Combdims=2;
P2=NPC_fwe(P_24,'T',options);

%Domini: t0.
     
for i=1:6 %i domini
    optionsD.labels.dims{2}=options.labels.dims{2}(domains==i)
    PD_24(:,i)=NPC(P_24(:,domains==i),'F',optionsD);
end
  
NPC_fwe(PD_24,'T');


%combining three times (through domains)
PD_times(:,:,3)=PD_24;
PD_times(:,:,2)=PD_4;
PD_times(:,:,1)=PD_0;

fprintf('\n*************Results: times combined\n')
options.Combdims=3;
Pdomain=NPC(PD_times,'T',options);

options.Combdims=2;
P2fwe=NPC_fwe(Pdomain,'T',options);

%combining three times (over variables)

P_times(:,:,3)=P_24;
P_times(:,:,2)=P_4;
P_times(:,:,1)=P_0;

fprintf('\n*************Results: times combined\n')
options.Combdims=3;
P=NPC(P_times,'T',options);
options.Combdims=2;
P2fwe=NPC_fwe(P,'T',options);

diary('OFF')
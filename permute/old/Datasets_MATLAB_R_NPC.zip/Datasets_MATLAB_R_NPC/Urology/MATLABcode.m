diary('loganalisiUrology.txt')
[D,data]=xlsimport('Urology.xls');
reminD(D)
B=10000;
Y=data(:,6:35);
X=data(:,1);
dati=expand_categ(Y,2);
p_value=NP_2s(dati,X,B,0,1);
TCC1=NPC(p_value(:,1),'T');
FOC1=NPC(p_value(:,2:3),'T');
T1=NPC(p_value(:,4:14),'T');
G1=NPC(p_value(:,15:18),'T');
CIS1=NPC(p_value(:,19:20),'T');
FOC2=NPC(p_value(:,21),'T');
T2=NPC(p_value(:,22:33),'T');
CIS2=NPC(p_value(:,34),'T');
G2=NPC(p_value(:,35:37),'T');
N2=NPC(p_value(:,38:40),'T');
M2=NPC(p_value(:,41),'T');
HighOBSTR2=NPC(p_value(:,42:43),'T');
T3=NPC(p_value(:,44:55),'T');
CIS3=NPC(p_value(:,56),'T');
G3=NPC(p_value(:,57:59),'T');
N3=NPC(p_value(:,60:62),'T');
M3=NPC(p_value(:,63),'T');
Histol3=NPC(p_value(:,64:68),'T');
infTRIG3=NPC(p_value(:,69),'T');
infCORPUS3=NPC(p_value(:,70),'T');
invURETH3=NPC(p_value(:,71),'T');
invVASC3=NPC(p_value(:,72),'T');
invLYMPH3=NPC(p_value(:,73),'T');
invPROST3=NPC(p_value(:,74),'T');
ADENcrPR3=NPC(p_value(:,75),'T');
HighTCC3=NPC(p_value(:,76),'T');
desease3=NPC(p_value(:,77),'T');
CHTpreOP3=NPC(p_value(:,78),'T');
CHTpostOP3=NPC(p_value(:,79),'T');
therapy3=NPC(p_value(:,80),'T');

phase1=NPC(p_value(:,1:20),'T');

phase2=NPC(p_value(:,21:43),'T');
 
phase3_1=NPC(p_value(:,44:68),'T');

phase3_2=NPC(p_value(:,69:74),'T');
phase3_3=NPC(p_value(:,75:80),'T');


domain=[phase1 phase2 phase3_1 phase3_2 phase3_3];
P_adj=NPC_FWE(domain,'T');

variable=[TCC1 FOC1 T1 G1 CIS1 FOC2 T2 CIS2 G2 N2 M2 HighOBSTR2 T3 CIS3 G3 N3 M3 Histol3 infTRIG3 infCORPUS3 invURETH3 invVASC3 invLYMPH3 invPROST3 ADENcrPR3 HighTCC3 desease3 CHTpreOP3 CHTpostOP3 therapy3];
P_adj=NPC_FWE(variable,'T');


diary('OFF')




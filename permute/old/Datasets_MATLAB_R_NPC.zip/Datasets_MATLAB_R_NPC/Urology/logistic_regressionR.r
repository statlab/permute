data=read.csv("urology.csv",header=TRUE)

attach(data)
mod1<-glm(group~TCC1+FOC1+T1+G1+CIS1+FOC2+T2+CIS2+G2+N2+M2+HighOBSTR2+T3+CIS3+G3+N3+M3+Histol3+infTRIG3+infCORPUS3+invURETH3+invVASC3+invLYMPH3+invPROST3+ADENcrPR3+HighTCC3+desease3+CHTpreOP3+CHTpostOP3+therapy3,family=binomial(link="logit"))
summary(mod1)
mod2<-glm(group~TCC1+FOC1+T1+G1+CIS1+FOC2+T2+CIS2+G2+N2+HighOBSTR2+T3+CIS3+G3+N3+Histol3+infTRIG3+infCORPUS3+invURETH3+invVASC3+invLYMPH3+invPROST3+ADENcrPR3+HighTCC3+CHTpreOP3+CHTpostOP3,family=binomial(link="logit"))
summary(mod2)
step(mod2)
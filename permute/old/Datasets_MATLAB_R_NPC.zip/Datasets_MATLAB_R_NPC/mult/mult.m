diary('mult.txt')

B=10000
[data,code,DATA]=xlsimport('mult');
Y=data(:,2:4);
X=data(:,1);
p=NP_2s(Y,X,B,0);

NPC_FWE(p,'F');

NPC_FWE(p,'T');

NPC_FWE(p,'L');

diary('OFF')
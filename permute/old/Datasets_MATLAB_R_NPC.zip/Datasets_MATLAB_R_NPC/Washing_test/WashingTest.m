diary('washingtest.txt')

B=1000
[data]=xlsimport('WashingTest');
strata=data(2);
Y=data(4);
X=data(1);
[P]=by_strata(strata, 'NP_Cs', Y,X, B, 1);
P2=NPC_FWE(P,'T',1);
d1=[6 10 12 20 21 25];
d2=[1 2 3 7 11 13 14 15 16 17 18 22 23 24];
d3=[4 5 8 9 19];
bleach=NPC(P(:,d1),'T',1);
detergency=NPC(P(:,d2),'T',1);
enzymatic=NPC(P(:,d3),'T',1);
NPC_FWE([bleach detergency enzymatic],'T',1);

diary('OFF')
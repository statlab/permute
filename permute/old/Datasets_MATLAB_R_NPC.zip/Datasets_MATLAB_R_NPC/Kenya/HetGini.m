function [H]=HetGini(A,M)
% calcola il vettore delle eterogeneit� secondo l'indice
% di Gini a partire dalle frequenze ordinate A e delle 
% numerosit� campionarie M
l=numel(M);
for i=1:l
    H(i)=1-sum(((A(i,:)/M(i))').^2);
end 
function[H]=HetShe(A,M)
% calcola il vettore delle eterogeneit� secondo l'indice
% di Shannon a partire dalle frequenze ordinate A e delle 
% numerosit� campionarie M

l=size(A);
for i=1:l(1)                                                         
    for j=1:l(2) 
        if A(i,j)==0 
            P(i,j)=1; 
        else P(i,j)=A(i,j)/M(i);
        end
    end
end
for i=1:l(1)
    H(i)=-sum(P(i,:).*log(P(i,:)))';
end
 
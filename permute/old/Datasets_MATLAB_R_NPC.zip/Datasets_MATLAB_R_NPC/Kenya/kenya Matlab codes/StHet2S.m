function [s]=StHet2S(H,M)
% funzione che calcola la statistica del test di
% eterogeneit� per c campioni a partire dai c
% valori di eterogeneit� dei singoli campioni e
% dell'eterogeneit� del campione pool.
% H = vettore delle c+1 eterogeneit�
% M = vettore delle c+1 dimensioni campionarie
d=numel(H);
s=H(1)-H(2);

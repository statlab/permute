function [H]=HetReInf(A,M)
l=numel(M);
for i=1:l
    H(i)=-log(max((A(i,:)/M(i))));
end 
diary('Kenya.txt')

F=xlsread('Kenya'); 
b=10000;                        
d=size(F);
c=d(1);                         
k=d(2);                         
G=zeros(c+1,k);
G(1:c,:)=sort(F','ascend')';                
G(c+1,:)=sort(sum(F)','ascend')';        
N=sum(G')';                     

s=0;
q=0;
Xo=zeros(N(c+1),2);
for i=1:c
    Xo(s+1:s+N(i),1)=i*ones(N(i),1);
    for j=1:k
        Xo(q+1:q+G(i,j),2)=j*ones(G(i,j),1);
        q=q+G(i,j);
    end
    s=s+N(i);
end

E=Space_perm(N(c+1),b);
X=zeros(N(c+1),2);
X(:,1)=Xo(:,1);
for i=1:b+1
    for j=1:N(c+1)
        X(E(i,j),2)=Xo(j,2);
    end
    G(1:c,:)=zeros(c,k);
    for j=1:N(c+1)
        r=X(j,1);
        t=X(j,2);
        G(r,t)=G(r,t)+1;
    end
   Gini=HetGini(G,N);           
   Shannon=HetShe(G,N);         
   %Renyi03=HetRe03(G,N);        
   RenyiInf=HetReInf(G,N);      
   Tg(i)=StHet2S(Gini,N);       
   Ts(i)=StHet2S(Shannon,N);    
   %Tr3(i)=StHet2S(Renyi03,N);   
   Tri(i)=StHet2S(RenyiInf,N);  
end
Pg=0;
Ps=0;
%Pr3=0;
Pri=0;
for i=1:b
    if Tg(i)>=Tg(b+1)
        Pg=Pg+1/b;
    end
    if Ts(i)>=Ts(b+1)
        Ps=Ps+1/b;
    end
    %if Tr3(i)>=Tr3(b+1)
    %    Pr3=Pr3+1/b;
    %end
    if Tri(i)>=Tri(b+1)
        Pri=Pri+1/b;
    end
end

fprintf('\n ---> Tg:%4.4f \n ---> Ts:%4.4f \n ---> Tri:%4.4f \n', Tg(b+1),Ts(b+1),Tri(b+1));
fprintf('\n ---> Pg:%4.4f \n ---> Ps:%4.4f \n ---> Pri:%4.4f \n', Pg,Ps,Pri);

diary('off')


diary('loganalisiCHROM17.txt')
[F]=xlsimport('chrom17m.xls');
reminD(F);

b=10000;                           
x=F(:,1).vals;
y=F(:,2).vals;
options.out=[1 1];
[Pf,Tf,options,Pf_sub,Tf_sub]=NP_Cs_Categ(y,x,b,2,'F',options);

[Pt,Tt,options,Pt_sub,Tt_sub]=NP_Cs_Categ(y,x,b,2,'T',options);
diary('OFF')